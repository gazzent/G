import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()

def _must_get(name: str) -> str:
    val = os.getenv(name)
    if not val:
        raise RuntimeError(f"Missing required env var: {name}")
    return val

def _parse_admin_ids(raw: str) -> list[int]:
    ids: list[int] = []
    for part in raw.split(","):
        part = part.strip()
        if not part:
            continue
        try:
            ids.append(int(part))
        except ValueError as e:
            raise RuntimeError(f"Invalid ADMIN_IDS item: {part}") from e
    return ids

@dataclass(frozen=True)
class Settings:
    bot_token: str
    admin_ids: list[int]
    db_path: str
    default_points: int
    cost_per_process: int
    tz: str

def load_settings() -> Settings:
    return Settings(
        bot_token=_must_get("BOT_TOKEN"),
        admin_ids=_parse_admin_ids(os.getenv("ADMIN_IDS", "")),
        db_path=os.getenv("DB_PATH", "data.sqlite3"),
        default_points=int(os.getenv("DEFAULT_POINTS", "3")),
        cost_per_process=int(os.getenv("COST_PER_PROCESS", "1")),
        tz=os.getenv("TZ", "UTC"),
    )
