import logging
from telegram.ext import ApplicationBuilder, CommandHandler
from config import load_settings
from db import init_db
from handlers import cmd_start, cmd_me, cmd_daily, cmd_process, cmd_addpoints

def main() -> None:
    settings = load_settings()

    logging.basicConfig(
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        level=logging.INFO,
    )
    log = logging.getLogger("tg-safe-adminpoints-bot")

    init_db(settings.db_path)
    log.info("DB ready at %s", settings.db_path)

    app = ApplicationBuilder().token(settings.bot_token).build()
    app.bot_data["settings"] = settings

    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("me", cmd_me))
    app.add_handler(CommandHandler("daily", cmd_daily))
    app.add_handler(CommandHandler("process", cmd_process))
    app.add_handler(CommandHandler("addpoints", cmd_addpoints))

    log.info("Bot running...")
    app.run_polling(allowed_updates=["message"])

if __name__ == "__main__":
    main()
