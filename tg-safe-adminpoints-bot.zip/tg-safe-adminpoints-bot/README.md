# tg-safe-adminpoints-bot

Template bot Telegram (Python) yang aman:
- User punya poin, aksi tertentu mengurangi poin
- Admin bypass poin (unlimited)
- Config via `.env`
- DB SQLite

> Catatan: Template ini **bukan** bot untuk otomatisasi verifikasi/penyalahgunaan layanan pihak ketiga.

## Jalankan lokal
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# edit .env: isi BOT_TOKEN
python bot.py
```
