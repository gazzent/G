from dataclasses import dataclass
from db import get_conn

@dataclass
class User:
    user_id: int
    username: str | None
    points: int

def ensure_user(db_path: str, user_id: int, username: str | None, default_points: int) -> User:
    with get_conn(db_path) as conn:
        cur = conn.cursor()
        cur.execute("SELECT user_id, username, points FROM users WHERE user_id=?", (user_id,))
        row = cur.fetchone()
        if row:
            cur.execute("UPDATE users SET username=? WHERE user_id=?", (username, user_id))
            conn.commit()
            return User(user_id=row[0], username=row[1], points=row[2])

        cur.execute(
            "INSERT INTO users(user_id, username, points) VALUES(?,?,?)",
            (user_id, username, default_points),
        )
        conn.commit()
        return User(user_id=user_id, username=username, points=default_points)

def get_points(db_path: str, user_id: int) -> int:
    with get_conn(db_path) as conn:
        cur = conn.cursor()
        cur.execute("SELECT points FROM users WHERE user_id=?", (user_id,))
        row = cur.fetchone()
        return int(row[0]) if row else 0

def add_points(db_path: str, user_id: int, delta: int) -> int:
    with get_conn(db_path) as conn:
        cur = conn.cursor()
        cur.execute("UPDATE users SET points = points + ? WHERE user_id=?", (delta, user_id))
        conn.commit()
        return get_points(db_path, user_id)

def spend_points(db_path: str, user_id: int, cost: int) -> tuple[bool, int]:
    """Return (success, remaining_points)."""
    with get_conn(db_path) as conn:
        cur = conn.cursor()
        cur.execute("SELECT points FROM users WHERE user_id=?", (user_id,))
        row = cur.fetchone()
        if not row:
            return False, 0
        points = int(row[0])
        if points < cost:
            return False, points
        cur.execute("UPDATE users SET points = points - ? WHERE user_id=?", (cost, user_id))
        conn.commit()
        return True, points - cost

def log_action(db_path: str, user_id: int, action: str, meta: str | None = None) -> None:
    with get_conn(db_path) as conn:
        conn.execute(
            "INSERT INTO logs(user_id, action, meta) VALUES(?,?,?)",
            (user_id, action, meta),
        )
        conn.commit()
