from telegram import Update
from telegram.ext import ContextTypes
from points import ensure_user, get_points, add_points, spend_points, log_action
from config import Settings

def is_admin(settings: Settings, user_id: int) -> bool:
    return user_id in settings.admin_ids

async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    s: Settings = context.bot_data["settings"]
    u = update.effective_user
    user = ensure_user(s.db_path, u.id, u.username, s.default_points)

    role = "👑 Admin (UNLIMITED)" if is_admin(s, u.id) else "👤 User"
    await update.message.reply_text(
        "\n".join([
            "✅ Bot siap.",
            f"Role: {role}",
            f"Poin Anda: {user.points}",
            "",
            "Perintah:",
            "/me - lihat status",
            "/process - simulasi aksi berbiaya poin (admin bypass)",
            "/daily - klaim +1 poin (user)",
            "/addpoints <user_id> <jumlah> (admin)",
        ])
    )
    log_action(s.db_path, u.id, "start")

async def cmd_me(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    s: Settings = context.bot_data["settings"]
    u = update.effective_user
    ensure_user(s.db_path, u.id, u.username, s.default_points)
    pts = get_points(s.db_path, u.id)
    role = "👑 Admin (UNLIMITED)" if is_admin(s, u.id) else "👤 User"
    await update.message.reply_text(f"Role: {role}\nPoin: {pts}")
    log_action(s.db_path, u.id, "me")

async def cmd_daily(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    s: Settings = context.bot_data["settings"]
    u = update.effective_user
    ensure_user(s.db_path, u.id, u.username, s.default_points)

    if is_admin(s, u.id):
        await update.message.reply_text("Admin tidak perlu daily. Anda unlimited 🙂")
        return

    new_pts = add_points(s.db_path, u.id, 1)
    await update.message.reply_text(f"🎁 Daily claimed! Poin Anda sekarang: {new_pts}")
    log_action(s.db_path, u.id, "daily")

async def cmd_process(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    s: Settings = context.bot_data["settings"]
    u = update.effective_user
    ensure_user(s.db_path, u.id, u.username, s.default_points)

    if is_admin(s, u.id):
        await update.message.reply_text("✅ (Admin) Process dijalankan. (bypass poin)")
        log_action(s.db_path, u.id, "process", "admin_bypass")
        return

    ok, remaining = spend_points(s.db_path, u.id, s.cost_per_process)
    if not ok:
        await update.message.reply_text(
            f"❌ Poin tidak cukup. Butuh {s.cost_per_process}, Anda punya {remaining}.\n"
            "Gunakan /daily untuk tambah poin."
        )
        log_action(s.db_path, u.id, "process", "insufficient_points")
        return

    await update.message.reply_text(f"✅ Process dijalankan. Sisa poin: {remaining}")
    log_action(s.db_path, u.id, "process", f"cost={s.cost_per_process}")

async def cmd_addpoints(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    s: Settings = context.bot_data["settings"]
    u = update.effective_user

    if not is_admin(s, u.id):
        await update.message.reply_text("❌ Akses ditolak (admin only).")
        return

    if not context.args or len(context.args) < 2:
        await update.message.reply_text("Format: /addpoints <user_id> <jumlah>")
        return

    try:
        target_id = int(context.args[0])
        amount = int(context.args[1])
    except ValueError:
        await update.message.reply_text("user_id dan jumlah harus angka.")
        return

    if amount == 0:
        await update.message.reply_text("Jumlah tidak boleh 0.")
        return

    ensure_user(s.db_path, target_id, None, s.default_points)
    new_pts = add_points(s.db_path, target_id, amount)

    await update.message.reply_text(f"✅ Berhasil. Poin user {target_id} sekarang: {new_pts}")
    log_action(s.db_path, u.id, "addpoints", f"target={target_id},amount={amount}")
